package asteroids;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.stage.*;

public class Asteroids extends Application {
    
    private GestoreParametriConfigurazione configurazione;
    private GestoreArchivioPunteggi archivio;
    private Finestra finestra;
    private MotoreDiGioco engine;
    private GestoreLogRemoto log;
    private SalvataggioPartita salvataggio;
    
    
    public void setEventiButtons(){
        
        finestra.getGraficaDinamica().getMusicButton().setOnAction((ActionEvent evMusic) -> {
            Suono.cambiaStatoMusic();
            finestra.getGraficaDinamica().cambiaStatoMusicButton();
            finestra.getFrame().requestFocus();
        });
        
        finestra.getGraficaDinamica().getAudioButton().setOnAction((ActionEvent evAudio) -> {
            Suono.cambiaStatoAudio();
            finestra.getGraficaDinamica().cambiaStatoAudioButton();
            finestra.getFrame().requestFocus();
        });
        
        finestra.getGraficaDinamica().getStartButton().setOnAction((ActionEvent ev) -> {
            if(finestra.getGraficaDinamica().controllaNome()){
                engine.avviaGioco();
                log.inviaMessaggio(new MessaggioDiLog(configurazione.getParametri().indirizzoIPClient, "START"));
            }
            finestra.getFrame().requestFocus();
        });
    }
    
    public void start(Stage stage){
        configurazione = new GestoreParametriConfigurazione();
        ParametriConfigurazione parametri = configurazione.getParametri();
                
        salvataggio = new SalvataggioPartita(parametri.pathFileCache);
        final DatiSalvataggio dati = salvataggio.caricaDati();
        
        archivio = new GestoreArchivioPunteggi(parametri);
        archivio.caricaClassifica();
               
        finestra = new Finestra(parametri);     
        finestra.setClassificaVisuale(archivio.getListaClassifica());
        
        if(salvataggio.datiPresenti)
            finestra.getGraficaDinamica().setDati(dati);
        
        log = new GestoreLogRemoto(parametri.indirizzoIPServer, parametri.portaServer);
        log.inviaMessaggio(new MessaggioDiLog(parametri.indirizzoIPClient, "AVVIO"));
        
        engine = new MotoreDiGioco(finestra.getGraficaDinamica(), archivio);
        engine.impostaEventi(finestra.getScene(), parametri.indirizzoIPClient, log);
        
        if(salvataggio.datiPresenti)
            engine.caricaDati(dati);
        else
            engine.creaPartita();
        
        setEventiButtons();
        Suono.cambiaStatoMusic();
        
        stage.setOnCloseRequest((WindowEvent we)->{
            log.inviaMessaggio(new MessaggioDiLog(parametri.indirizzoIPClient, "TERMINE"));
            engine.salvaDati(dati);
            finestra.getGraficaDinamica().salvaDati(dati);
            salvataggio.salvaDati(dati);    
        });
        stage.setTitle("Asteroids");
        stage.setScene(finestra.getScene());
        stage.show();
    }
}
