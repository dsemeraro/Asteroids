package asteroids;

import java.io.Serializable;

public class DatiSalvataggio implements Serializable{
    public String nomeUtente;
    public int punteggio;
    public int vite;
    public OggettoDiGioco nave;
    public Asteroide[] asteroidi;
    public Missile[] missili;
}
