package asteroids;

import javafx.scene.paint.Color;


public class ParametriConfigurazione {
    public String fontFamily;
    public int fontSize;
    public int altezzaFinestra;
    public int larghezzaFinestra;
    public Color coloreSfondo;
    public int numeroRigheClassifica;
    public int numeroGiorniClassifica;
    public String indirizzoIPClient;
    public String indirizzoIPServer;
    public int portaServer;   
    public String usernameDB;
    public String passwordDB;
    public String pathFileCache;
    
    public ParametriConfigurazione(){
        fontFamily = "Arial";
        fontSize = 26;
        altezzaFinestra = 600;
        larghezzaFinestra = 800;
        coloreSfondo = Color.SLATEGRAY;
        numeroRigheClassifica = 10;
        numeroGiorniClassifica = 10;
        indirizzoIPClient = "localhost";
        indirizzoIPServer = "localhost";
        portaServer = 8080;
        usernameDB = "root";
        passwordDB = "";
        pathFileCache = "./myfiles/cache.bin";
    }
}
