
package asteroids;

import javafx.beans.property.*;

public class BeanUtente {
    private final SimpleStringProperty utente;
    private final SimpleIntegerProperty punteggio;
    
    public BeanUtente(String utente, int punteggio){
        this.utente = new SimpleStringProperty(utente);
        this.punteggio = new SimpleIntegerProperty(punteggio);
    }
    
    public String getUtente(){
        return utente.get();
    }
    
    public int getPunteggio(){
        return punteggio.get();
    }
}
