package asteroids;

import com.thoughtworks.xstream.*;
import java.io.*;
import java.nio.file.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

public class GestoreParametriConfigurazione {
    private final String pathFileXML;
    private final String pathFileXSD;
    public ParametriConfigurazione parametri;
    
    GestoreParametriConfigurazione(){
        pathFileXML = "myfiles/configurazione.xml";
        pathFileXSD = "myfiles/configurazione.xsd";
        parametri = new ParametriConfigurazione();
        if(validaXML())
           leggiParametri();
        //serializzaXML();
    }
    
    private void serializzaXML(){
        XStream xs = new XStream();
        String s = xs.toXML(parametri);
        try{
            Files.write(Paths.get(pathFileXML), s.getBytes());
        }catch(IOException ex){
            System.err.println(ex.getMessage());
        }
    }
    
    private void leggiParametri(){
        XStream xs = new XStream();
        String s = "";
        try{
            s = new String(Files.readAllBytes(Paths.get(pathFileXML)));
        }catch(IOException ex){
            System.err.println(ex.getMessage());
        }
        parametri = (ParametriConfigurazione) xs.fromXML(s);
    } 
    
    private boolean validaXML() {
        try {  
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Document d = db.parse(new File(pathFileXML));
            Schema s = sf.newSchema(new StreamSource(new File(pathFileXSD)));
            s.newValidator().validate(new DOMSource(d));
        }catch (Exception e) {
            if (e instanceof SAXException) 
                System.err.println("Errore di validazione: " + e.getMessage());
            else
                System.err.println(e.getMessage());
            return false;
        }
        return true;
    }
        
    public ParametriConfigurazione getParametri(){
        return parametri;
    }
}
