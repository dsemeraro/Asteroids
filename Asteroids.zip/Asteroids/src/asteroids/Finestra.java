
package asteroids;

import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

public class Finestra {
    private final Scene finestraVisuale;
    private final TableView<BeanUtente> classifica;
    private final VisualeElementiDiGioco graficaDinamica;
    private final Rectangle frameGioco;
   
    public Finestra(ParametriConfigurazione parametri){
        
        Font font = new Font(parametri.fontFamily, parametri.fontSize);
        graficaDinamica = new VisualeElementiDiGioco(font);
        
        classifica = new TableView<>();
        
        frameGioco = new Rectangle(500, 480);
        frameGioco.setFill(Color.BLACK);
        frameGioco.setLayoutX(280);
        frameGioco.setLayoutY(20);
        
        Group root = new Group(classifica, setEtichette(font),  frameGioco, graficaDinamica.getVisuale());
        finestraVisuale = new Scene(root, parametri.larghezzaFinestra,parametri.altezzaFinestra);
        finestraVisuale.setFill(parametri.coloreSfondo);
    }
    
    public void setClassificaVisuale(ObservableList<BeanUtente> lista){
        TableColumn colonnaUtente = new TableColumn("Utente");
        colonnaUtente.setCellValueFactory(new PropertyValueFactory<>("utente"));
        
        TableColumn colonnaPunteggio = new TableColumn("Punteggio");
        colonnaPunteggio.setCellValueFactory(new PropertyValueFactory<>("punteggio"));
        
        classifica.setItems(lista);
        classifica.getColumns().addAll(colonnaUtente, colonnaPunteggio);
        classifica.setFixedCellSize(28);
        classifica.resizeColumn(colonnaUtente, 39);
        classifica.resizeColumn(colonnaPunteggio, 39);
        classifica.setMaxSize(240, 280);
        classifica.relocate(20, 300);
    }
    
    private Group setEtichette(Font font){
        
        Label etichettaNome = new Label("Nome Utente");
        etichettaNome.setFont(font);
                
        Label etichettaPunteggio = new Label("Punteggio");
        etichettaPunteggio.setFont(font);
        
        Label etichettaClassifica = new Label("Classifica");
        etichettaClassifica.setFont(font);
        
        Label etichettaVite = new Label("Vite");
        etichettaVite.setFont(font);
        etichettaVite.setLayoutX(670);
        etichettaVite.setLayoutY(505);
        
        VBox vbox = new VBox(90);
        vbox.getChildren().addAll(etichettaNome, etichettaPunteggio, etichettaClassifica);
        vbox.setAlignment(Pos.CENTER);
        vbox.setMaxHeight(560);
        vbox.setMinWidth(240);
        vbox.setLayoutX(20);
        vbox.setLayoutY(20);
        
        Group gruppoEtichette = new Group(vbox, etichettaVite);
        
        return gruppoEtichette;
    }
    
    public Scene getScene(){
        return finestraVisuale;
    }

    public VisualeElementiDiGioco getGraficaDinamica(){
        return graficaDinamica;
    }
    
    public Rectangle getFrame(){
        return frameGioco;
    }
}
