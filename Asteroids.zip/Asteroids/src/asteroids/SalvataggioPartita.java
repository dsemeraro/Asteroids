package asteroids;

import java.io.*;

public class SalvataggioPartita {
    private final String pathFileSalvataggio;
    public boolean datiPresenti = false;
    
    public SalvataggioPartita(String path){
        pathFileSalvataggio = path;
    }
    
    public void salvaDati(DatiSalvataggio dati){
        try(
            FileOutputStream fout = new FileOutputStream(pathFileSalvataggio);
            ObjectOutputStream oout = new ObjectOutputStream(fout)
        ){
            oout.writeObject(dati);
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
    }
    
    public DatiSalvataggio caricaDati(){
        DatiSalvataggio dati;
        try(
            FileInputStream fin = new FileInputStream(pathFileSalvataggio);
            ObjectInputStream oin = new ObjectInputStream(fin)
        ){
            dati = (DatiSalvataggio) oin.readObject();
            datiPresenti = true;
        }catch (IOException|ClassNotFoundException ex) {
            System.err.println(ex.getMessage());
            dati = new DatiSalvataggio();
        }
        return dati;
    }
   
}
