package asteroids;

import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class VisualeElementiDiGioco {
    private final TextField nomeUtente;
    private final Label punteggio;
    private final Label gameOver;
    private Button startButton;
    private Button musicOnOff;
    private Button audioEffectOnOff;
    private final Group visuale;
    private ImageView[] viteVisuale;
    
    public VisualeElementiDiGioco(Font font){
        
        nomeUtente = new TextField("");
        nomeUtente.setFont(font);
        nomeUtente.setMaxWidth(240);
        nomeUtente.setLayoutX(20);
        nomeUtente.setLayoutY(60);
     
        punteggio = new Label(Integer.toString(0));
        punteggio.setLayoutY(180);
        punteggio.setLayoutX(20);
        punteggio.setFont(font);
        punteggio.setMinWidth(240);
        punteggio.setAlignment(Pos.CENTER);
        
        gameOver = new Label("GAME OVER");
        gameOver.setLayoutX(460);
        gameOver.setLayoutY(150);
        gameOver.setFont(font);
        gameOver.setTextFill(Color.RED);
        gameOver.setVisible(false);
        
        setButtons(font);
        
        visuale = new Group(nomeUtente, punteggio, gameOver, startButton, musicOnOff, audioEffectOnOff);
        setViteVisuale(3);
    }
    
    private void setButtons(Font font){
        startButton = new Button("Start");
        startButton.setLayoutX(460);
        startButton.setLayoutY(530);
        startButton.setMinWidth(120);
        startButton.setMaxHeight(40);
        startButton.setFont(font);
        
        musicOnOff = new Button();
        musicOnOff.setLayoutX(680);
        musicOnOff.setLayoutY(550);
        musicOnOff.setMinSize(25, 25);
        musicOnOff.setGraphic(new ImageView("file:../../myfiles/immagini/musicOn.png"));
        
        audioEffectOnOff = new Button();
        audioEffectOnOff.setLayoutX(725);
        audioEffectOnOff.setLayoutY(550);
        audioEffectOnOff.setMinSize(25, 25);
        audioEffectOnOff.setGraphic(new ImageView("file:../../myfiles/immagini/audioOn.png"));
    }
    
    private void setViteVisuale(int n){
        viteVisuale = new ImageView[3];
        for(int i = 0; i < n; i++){
            viteVisuale[i] = new ImageView("file:../../myfiles/immagini/vita.png");
            viteVisuale[i].setLayoutX(720+ i*20);
            viteVisuale[i].setLayoutY(510);
            visuale.getChildren().add(viteVisuale[i]);
        }
    }
    
    public void rimuoviVita(int i){
        visuale.getChildren().remove(viteVisuale[i]);
    }
    
    public Group getVisuale(){
        return visuale;
    }
    
    public Button getStartButton(){
        return startButton;
    }
    
    public Button getAudioButton(){
        return audioEffectOnOff;
    }
    
    public Button getMusicButton(){
        return musicOnOff;
    }
    
    public String getNomeUtente(){
        return nomeUtente.getText();
    }
    
    public int getPunteggio(){
        return Integer.parseInt(punteggio.getText());
    }

    public void incrementaPunteggio(int i) {
        int x = Integer.parseInt(punteggio.getText());
        x += i;
        punteggio.setText(Integer.toString(x));
    }
    
    public boolean controllaNome(){
        boolean nomeInserito = !nomeUtente.getText().isEmpty();
        if(!nomeInserito){
            nomeUtente.setBackground(new Background(new BackgroundFill(Color.LIGHTCORAL, new CornerRadii(5), null)));
        }else{
            nomeUtente.setBackground(new Background(new BackgroundFill(Color.WHITE, new CornerRadii(5), null)));
        }
        return nomeInserito;
    }
    
    public void setDati(DatiSalvataggio dati){
        for(int i = 0; i < 3; i++) rimuoviVita(i);
        setViteVisuale(dati.vite);
        nomeUtente.setText(dati.nomeUtente);
        punteggio.setText(Integer.toString(dati.punteggio));
    }
    
    public void salvaDati(DatiSalvataggio dati){
        dati.nomeUtente = nomeUtente.getText();
        dati.punteggio = Integer.parseInt(punteggio.getText());
    }
    
    public void setGameOver(){
        punteggio.setText("0");
        setViteVisuale(3);
        gameOver.setVisible(true);
    }
    
    public void rimuoviGameOver(){
        gameOver.setVisible(false);
    }

    void cambiaStatoAudioButton(){
        if(Suono.isAudioOn())
            audioEffectOnOff.setGraphic(new ImageView("file:../../myfiles/immagini/audioOn.png")); //(1)
        else
            audioEffectOnOff.setGraphic(new ImageView("file:../../myfiles/immagini/audioOff.png")); //(1)
    }

    void cambiaStatoMusicButton() {
        if(Suono.isMusicOn())
            musicOnOff.setGraphic(new ImageView("file:../../myfiles/immagini/musicOn.png"));  //(1)
        else
            musicOnOff.setGraphic(new ImageView("file:../../myfiles/immagini/musicOff.png"));  //(1)
    }
    
}

 //(1) - icone scaricate da icons8.com