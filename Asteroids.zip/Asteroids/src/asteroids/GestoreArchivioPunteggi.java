package asteroids;

import java.sql.*;
import javafx.collections.*;

public class GestoreArchivioPunteggi {
    private final ObservableList<BeanUtente> lista;
    private final String usernameDB;
    private final String passwordDB;
    private final int nGiorni;
    private final int nRighe;
    
    public GestoreArchivioPunteggi(ParametriConfigurazione parametri){
        lista = FXCollections.observableArrayList();
        usernameDB = parametri.usernameDB;
        passwordDB = parametri.passwordDB;
        
        nGiorni = parametri.numeroGiorniClassifica;
        nRighe = parametri.numeroRigheClassifica;
    }
    
    public void caricaClassifica(){
        lista.clear();
        try(
            Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/archiviopunteggi", usernameDB, passwordDB);
            PreparedStatement ps = co.prepareStatement(
                    "SELECT utente, punteggio " +
                    "FROM punteggi " +
                    "WHERE data > CURRENT_DATE - INTERVAL ?  DAY " +
                    "ORDER BY punteggio DESC " +
                    "LIMIT ?;");
        ){ 
            ps.setInt(1, nGiorni);
            ps.setInt(2, nRighe);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                lista.add(new BeanUtente(rs.getString("utente"), rs.getInt("punteggio")));
            }
        }catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    
    public void salvaPunteggio(String nomeUtente, int punteggio){
        try(
            Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/archiviopunteggi", usernameDB, passwordDB);
            PreparedStatement ps = co.prepareStatement(
                   "INSERT INTO punteggi (utente, punteggio, data) VALUES (?,?, CURRENT_DATE)"
                );
        ){ 
            ps.setString(1, nomeUtente);
            ps.setInt(2, punteggio);
            System.out.println("rows affected: "+ ps.executeUpdate());
        }catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    
    public ObservableList<BeanUtente> getListaClassifica(){
        return lista;
    }
}
