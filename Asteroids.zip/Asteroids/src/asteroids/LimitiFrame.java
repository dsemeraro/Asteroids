package asteroids;


public interface LimitiFrame {
    int LIMITE_SUP_FRAME = 20;
    int LIMITE_INF_FRAME = 500;
    int LIMITE_SIN_FRAME = 280;
    int LIMITE_DES_FRAME = 780;
}
