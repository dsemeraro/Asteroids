package asteroids;

import javafx.scene.Group;

public class Missile extends OggettoDiGioco{
    public int tempoVita = 0;
    
    public Missile(float x, float y, int direzione, Group gruppoParentVisuale){
        super(x, y, direzione, 7, 5, gruppoParentVisuale);
        disegna();
    }
    
    public void handle(long now) {
        muovi();
        tempoVita++;
    }
    
}
