package asteroids;

import com.thoughtworks.xstream.XStream;
import java.io.*;
import java.net.*;

class GestoreLogRemoto {

    private final String indirizzoIPServer;
    private final int portaConnessione;

    public GestoreLogRemoto(String ipServer, int porta){
        indirizzoIPServer = ipServer;
        portaConnessione = porta;
    }

    public void inviaMessaggio(MessaggioDiLog m){
        XStream xs = new XStream();
        try(
            Socket socketConnessione = new Socket(indirizzoIPServer, portaConnessione);
            DataOutputStream dout = new DataOutputStream(socketConnessione.getOutputStream());
        ){
            dout.writeUTF(xs.toXML(m));
        }catch (IOException ex){
            System.err.println(ex.getMessage());
        }
    }
}
