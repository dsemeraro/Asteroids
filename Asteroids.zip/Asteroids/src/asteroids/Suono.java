
package asteroids;

import java.io.File;
import javafx.scene.media.*;

public class Suono {
    private static final String pathSparo = "./myfiles/audio/sparo.wav"; //(1)
    private static final String pathEsplosione = "./myfiles/audio/esplosione.wav"; //(1)
    private static final String pathMusic = "./myfiles/audio/phantom_from_space.mp3"; //(2)
    
    private static final AudioClip sparo = new AudioClip(new File(pathSparo).toURI().toString());
    private static final AudioClip esplosione = new AudioClip(new File(pathEsplosione).toURI().toString());
    
    private static final Media musicMedia = new Media(new File(pathMusic).toURI().toString());
    private static final MediaPlayer musicPlayer = new MediaPlayer(musicMedia);
    
    private static boolean audioOn = true;
    private static boolean musicOn = false; 
    
    public static void suonaSparo(){
        if(audioOn)
            sparo.play();
    }
    
    public static void suonaEsplosione(){
        if(audioOn)
            esplosione.play();
    }
    
    public static void cambiaStatoAudio(){
        audioOn = !audioOn;
    }
    
    public static void cambiaStatoMusic(){
        musicOn = !musicOn;
        if(musicOn)
            musicPlayer.play();
        else
            musicPlayer.stop();
    }
    
    public static boolean isAudioOn(){
        return audioOn;
    }
    
    public static boolean isMusicOn(){
        return musicOn;
    }
}
//(1) - effetti audio scaricati da freesound.org
//(2) - Music: "Phantom from Space" by Kevin MacLeod. Available under the Creative Commons Attribution 3.0 Unported license