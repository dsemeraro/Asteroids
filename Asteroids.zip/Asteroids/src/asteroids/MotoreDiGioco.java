package asteroids;

import javafx.animation.AnimationTimer;
import javafx.scene.Scene;
import javafx.scene.input.*;

public class MotoreDiGioco extends AnimationTimer implements LimitiFrame{
    
    private final int MAX_MISSILI = 5;
    private final int MAX_ASTEROIDI = 10;
    
    private final VisualeElementiDiGioco visualeElementi;
    private final GestoreArchivioPunteggi gestorePunteggi;
    private int vite;
    private Navicella nave;
    private Asteroide[] asteroidi;
    private Missile[] missili;
    private boolean giocoInCorso;
    private int timer;
            
    public MotoreDiGioco(VisualeElementiDiGioco elementi, GestoreArchivioPunteggi archivio){
        vite = 3;
        timer = 0;
        visualeElementi = elementi;
        
        missili = new Missile[MAX_MISSILI];
        asteroidi = new Asteroide[MAX_ASTEROIDI];
        
        gestorePunteggi = archivio;
    }

    public void caricaDati(DatiSalvataggio dati) {
        vite = dati.vite;
        float x = dati.nave.x;
        float y = dati.nave.y;
        int dir = dati.nave.getDirezione();

        nave = new Navicella(x, y, dir, visualeElementi.getVisuale());
        
        asteroidi = dati.asteroidi;
        for(Asteroide ast : asteroidi){
            if(ast != null){
                ast.setParent(visualeElementi.getVisuale());
                ast.disegna();
            }
        }
        
        missili = dati.missili;
        for(Missile m : missili){
            if(m != null){
                m.setParent(visualeElementi.getVisuale());
                m.disegna();
            }
        }
    }
    
    public void salvaDati(DatiSalvataggio dati){
        dati.vite = vite;
        nave.setPosizioneSalvataggio();
        dati.nave = nave;
        for(Asteroide a : asteroidi)
            if(a != null) a.setPosizioneSalvataggio();
        dati.asteroidi = asteroidi;
        for(Missile m: missili)
            if(m != null) m.setPosizioneSalvataggio();
        dati.missili = missili;
    }
    
    public void creaPartita(){ 
        nave = new Navicella(530, 250, 180, visualeElementi.getVisuale());
        for (int i = 0; i < 3; i++)
            creaAsteroide();
    }
    
    public void impostaEventi(Scene finestra, String ip, GestoreLogRemoto log){
        
        finestra.setOnKeyPressed((KeyEvent event) -> {
            if(giocoInCorso){
                if(event.getCode().isArrowKey()){      //(1)
                    nave.impostaMovimento(event.getCode(), true);
                    log.inviaMessaggio(new MessaggioDiLog(ip, event.getCode().toString())); 
                }
                if(event.getCode() == KeyCode.SPACE){
                    creaMissile();
                    log.inviaMessaggio(new MessaggioDiLog(ip, event.getCode().toString()));
                    Suono.suonaSparo();
                }
            }
            
            if(event.getCode() == KeyCode.ENTER){
                log.inviaMessaggio(new MessaggioDiLog(ip, event.getCode().toString())); 
                if(giocoInCorso)
                    pausaGioco();
                else
                    avviaGioco();
            }
            event.consume();  
        });
        
        finestra.setOnKeyReleased((KeyEvent event) -> {
            if(event.getCode().isArrowKey())
                nave.impostaMovimento(event.getCode(), false);
            event.consume();  
        });
    }
    
    private void creaAsteroide(){ //(1)
        int x, y;
        double distanzaNave, distanzaX, distanzaY;
        int direzione = (int)(Math.random() * 360);
        int i = 0;
        do{
            x = (int) (Math.random() * 460) + LIMITE_SIN_FRAME;
            y = (int) (Math.random() * 440) + LIMITE_SUP_FRAME;
            distanzaX = x - nave.getVisuale().getLayoutX();
            distanzaY = y - nave.getVisuale().getLayoutY();
            distanzaNave = Math.sqrt(distanzaX * distanzaX + distanzaY * distanzaY);
        } while(distanzaNave < 100);
        
        while(i < MAX_ASTEROIDI && asteroidi[i] != null) i++;
        
        if(i < MAX_ASTEROIDI){
            asteroidi[i] = new Asteroide(x, y, direzione, visualeElementi.getVisuale());
            if(giocoInCorso) asteroidi[i].start();
        }
    }

    private void creaMissile(){
        int i = 0;
        while(i < MAX_MISSILI && missili[i] != null)
            i++;
        if(i < MAX_MISSILI){
            float x = (float) nave.getVisuale().getLayoutX() + 10;
            float y = (float) nave.getVisuale().getLayoutY() + 10;
            missili[i] = new Missile(x, y, nave.getDirezione(), visualeElementi.getVisuale());
            missili[i].start();
        }
    }
    
    private void rimuoviAsteroide(int i){
        asteroidi[i].stop();
        asteroidi[i].cancella();
        asteroidi[i] = null;
    }
     
    private void rimuoviMissile(int i){
        missili[i].stop();
        missili[i].cancella();
        missili[i] = null;
    }
    
    private void rimuoviVita(){
        giocoInCorso = false;
        pulisciFrameGioco();

        visualeElementi.rimuoviVita(--vite);

        if(vite == 0)
            perdi();
        
        creaPartita();
    }
    
    private void pulisciFrameGioco(){
        nave.cancella();
        
        for(int i = 0; i < MAX_ASTEROIDI; i++)
            if(asteroidi[i] != null){
                rimuoviAsteroide(i);
            }
        
        for(int j = 0; j < MAX_MISSILI; j++)
            if(missili[j] != null){
                rimuoviMissile(j);
            }
        stop();
    }
    
    private void pausaGioco(){
        giocoInCorso = false;
        nave.stop();
        for(Asteroide a : asteroidi)
            if(a != null)
                a.stop();
        for(Missile m: missili)
            if(m != null)
                m.stop();
        stop();
    }
    
    public void avviaGioco(){
        giocoInCorso = true;
        visualeElementi.rimuoviGameOver();
        nave.start();
        for(Asteroide a : asteroidi)
            if(a != null)
                a.start();
        for(Missile m: missili)
            if(m != null)
                m.start();
        start();
    }
    
    private void perdi(){
        gestorePunteggi.salvaPunteggio(visualeElementi.getNomeUtente(), visualeElementi.getPunteggio());
        gestorePunteggi.caricaClassifica();
        vite = 3;
        visualeElementi.setGameOver();
    }
    
    private void controllaCollisioni(){
        for(int i = 0; i < MAX_ASTEROIDI; i++){
           if(asteroidi[i] != null){
                if (asteroidi[i].collide(nave)){
                    rimuoviVita();
                } else {
                    for(int j = 0; j < MAX_MISSILI; j++)
                        if(missili[j] != null)
                            if(asteroidi[i].collide(missili[j])){
                                visualeElementi.incrementaPunteggio(5);
                                rimuoviAsteroide(i);
                                rimuoviMissile(j);
                                Suono.suonaEsplosione();
                                break;
                            }
                }
            }
        }
        for(int k = 0; k < MAX_MISSILI; k++)  //(2)
            if(missili[k] != null && missili[k].tempoVita > 50){ 
                rimuoviMissile(k);
            }
    }
    
    public void handle(long now){
        controllaCollisioni();
        timer++;
        if(timer % 100 == 0){
            creaAsteroide();
        }
    }   
}


/*
 (1) - la funzione cerca una posizione random per il nuovo asteroide che sia ad almeno 100 px di distanza dalla nave
 (2) - in questo modo i missili vengono distrutti dopo un po' di tempo
*/
