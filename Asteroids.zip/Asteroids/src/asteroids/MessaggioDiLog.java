
package asteroids;

import java.sql.Timestamp;

public class MessaggioDiLog {
    String nomeApplicazione;
    String indirizzoIpClient;
    String timestamp;
    String evento;
    
    public MessaggioDiLog(String ip, String ev){
        nomeApplicazione = "Asteroids";
        
        indirizzoIpClient = ip;
        
        Timestamp ts = new Timestamp(System.currentTimeMillis());
        timestamp = ts.toString();
               
        evento = ev;
    }
}
