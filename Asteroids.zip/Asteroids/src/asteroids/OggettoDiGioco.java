
package asteroids;

import java.io.Serializable;
import javafx.animation.AnimationTimer;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public abstract class OggettoDiGioco extends AnimationTimer implements LimitiFrame, Serializable{
    public float x;
    public float y;
    private int direzione;
    private final int velocita;
    private final int dimensione;
    private transient Node visuale;
    private transient Group parentGrafica;
    
    public OggettoDiGioco(float x, float y, int dir, int vel, int dim, Group gruppoParentVisuale){
        this.x = x;
        this.y = y;
        direzione = dir;
        velocita = vel;
        dimensione = dim;
        parentGrafica = gruppoParentVisuale;
    }
    
    public void setParent(Group gruppoParentVisuale){ //(1)
        parentGrafica = gruppoParentVisuale;
    }
    
    public Group getParent(){ //(2)
        return parentGrafica;
    }
    
    public void disegna(){
        Rectangle disegno = new Rectangle(dimensione, dimensione);
        disegno.setFill(Color.LIGHTGRAY);
        disegno.setLayoutX(x);
        disegno.setLayoutY(y);
        visuale = disegno;
        parentGrafica.getChildren().add(visuale);
    }
    
    public void cancella(){
        parentGrafica.getChildren().remove(visuale);
    }
    
    public void setVisuale(Node view){
        visuale = view;
    }
    
    public Node getVisuale(){
        return visuale;
    }
    
    public int getDirezione(){
        return direzione;
    }
    
    public void setDirezione(int d){
        direzione = d;
    }
    
    public void setPosizioneSalvataggio(){
        x = (float) visuale.getLayoutX();
        y = (float) visuale.getLayoutY();
    }
    
    public void muovi(){ //(3)
        float x1 = (float) (visuale.getLayoutX() + velocita * Math.sin((direzione*Math.PI)/180));
        float y1 = (float) (visuale.getLayoutY() + velocita * Math.cos((direzione*Math.PI)/180));
        visuale.setLayoutX(x1);
        visuale.setLayoutY(y1);
        
        if(visuale.getLayoutX() < LIMITE_SIN_FRAME) 
            riposiziona(LIMITE_DES_FRAME - dimensione, y1);
        else if(visuale.getLayoutX() > LIMITE_DES_FRAME - dimensione)
            riposiziona(LIMITE_SIN_FRAME, y1);
        if(visuale.getLayoutY() < LIMITE_SUP_FRAME) 
            riposiziona(x1, LIMITE_INF_FRAME - dimensione);
        else if(visuale.getLayoutY() > LIMITE_INF_FRAME - dimensione) 
            riposiziona(x1, LIMITE_SUP_FRAME);
    }
    
    public void riposiziona(float nuovaX, float nuovaY){
        visuale.setLayoutX(nuovaX);
        visuale.setLayoutY(nuovaY);
    }
    
    public boolean collide(OggettoDiGioco altro){
        return visuale.getBoundsInParent().intersects(altro.visuale.getBoundsInParent());
    }
}


// (1) - serve per settare il gruppo parent nel casi l'oggetto sia stato istanziato da cache locale
// (2) - serve alla sottoclasse Navicella per accedere alla variabile gruppoParent 
//       utilizzata nella funzione disegna()
// (3) - la funzione usa le costanti definite nell'interfaccia LimitiFrame per riposizionare 
//       l'oggetto nella parte opposta del frame nel caso in cui questo ne superi un bordo.