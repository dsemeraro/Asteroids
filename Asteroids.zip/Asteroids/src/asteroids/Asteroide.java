package asteroids;

import javafx.scene.Group;

public class Asteroide extends OggettoDiGioco {
    
    public Asteroide(float x, float y, int direzione, Group gruppoParentVisuale) {
        super(x, y, direzione,(int)(1 + Math.random() * 3), 40, gruppoParentVisuale);
        disegna();
    }
   
    public void handle(long now) {
        muovi();
    }

}
