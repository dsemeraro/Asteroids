package asteroids;

import javafx.scene.Group;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;

public class Navicella extends OggettoDiGioco{
    private boolean destra = false;
    private boolean sinistra = false;
    private boolean avanti = false;
    
    public Navicella(float x, float y, int direzione, Group gruppoParentVisuale) {
        super(x, y, direzione, 5, 20, gruppoParentVisuale);
        disegna();
    }
    
    public final void disegna(){
        ImageView disegno = new ImageView("file:../../myfiles/immagini/nave.png");
        disegno.setRotate(-getDirezione());
        disegno.setLayoutX(x);
        disegno.setLayoutY(y);
        setVisuale(disegno);
        getParent().getChildren().add(disegno);
    }
    
    public void handle(long now) {
        if(avanti)
            muovi();
        if(destra && !sinistra){
            getVisuale().setRotate(getVisuale().getRotate() + 5);
            setDirezione(getDirezione() - 5);
        }
        if(sinistra && !destra){
            getVisuale().setRotate(getVisuale().getRotate() - 5);
            setDirezione(getDirezione() + 5);
        }
    }

    public void impostaMovimento(KeyCode code, boolean premuto) {
        switch(code){
            case UP:
                avanti = premuto;
                break;
            case LEFT:
                sinistra = premuto;
                break;
            case RIGHT:
                destra = premuto;
        }
    }
}
