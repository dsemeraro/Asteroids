package serverlog;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.*;
import org.xml.sax.SAXException;

public class ServerLog {
    private static final String pathFileXML = "./myfiles/Log.xml";
    private static final String pathFileXSD = "./myfiles/MessaggioDiLogSchema.xsd";
    
    public static void main(String[] args){
        try(ServerSocket server = new ServerSocket(8080);){
            while(true){
                try(
                    Socket s = server.accept();
                    DataInputStream din = new DataInputStream(s.getInputStream())
                ){
                    salvaLog(din.readUTF());
                }
            }
        }catch (IOException ex) {
                ex.printStackTrace();
        }
    }
    
    private static void salvaLog(String xml){
        xml = xml + "\n";
        try {  
            SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema s = sf.newSchema(new StreamSource(new File(pathFileXSD)));
            s.newValidator().validate(new StreamSource(new StringReader(xml)));
            
            Files.write(Paths.get(pathFileXML), xml.getBytes(), StandardOpenOption.APPEND);
            
        }catch (SAXException e){ 
                System.err.println("Errore di validazione: " + e.getMessage());
        }catch(IOException e){
            try{
                Files.createFile(Paths.get(pathFileXML));   //(1)
                Files.write(Paths.get(pathFileXML), xml.getBytes());
            }catch(IOException ex){
                System.err.println(ex.getMessage());
            }
        }
    }
}

// (1) - se il file non esiste viene creato e viene ripetuta la scrittura
